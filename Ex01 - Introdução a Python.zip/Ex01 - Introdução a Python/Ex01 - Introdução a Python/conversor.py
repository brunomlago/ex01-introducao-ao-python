# Definindo funções de conversão

def pe_para_metro(pe):
    return pe * 0.3048


def metro_para_pe(metro):
    return metro * 3.28084


def jarda_para_metro(jarda):
    return jarda * 0.9144


def metro_para_jarda(metro):
    return metro / 0.9144


def jarda_para_pe(jarda):
    return jarda * 3


def pe_para_jarda(pe):
    return pe / 3