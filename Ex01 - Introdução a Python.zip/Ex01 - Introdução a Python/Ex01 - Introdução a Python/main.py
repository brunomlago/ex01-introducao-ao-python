import conversor

origem = input("Unidade de origem: ").lower()
valor = float(input("Valor: "))
destino = input("Unidade de destino: ").lower()

if origem == "pé" and destino == "metro":
    resultado = conversor.pe_para_metro(valor)

elif origem == "metro" and destino == "pé":
    resultado = conversor.metro_para_pe(valor)

elif origem == "jarda" and destino == "metro":
    resultado = conversor.jarda_para_metro(valor)

elif origem == "metro" and destino == "jarda":
    resultado = conversor.metro_para_jarda(valor)

elif origem == "jarda" and destino == "pé":
    resultado = conversor.jarda_para_pe(valor)

elif origem == "pé" and destino == "jarda":
    resultado = conversor.pe_para_jarda(valor)

else:
    print("Conversão não disponível.")
    resultado = None

if resultado is not None:
    print("Saída:", resultado)